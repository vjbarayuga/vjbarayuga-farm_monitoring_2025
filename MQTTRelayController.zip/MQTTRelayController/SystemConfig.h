#ifndef SYSTEM_CONFIG_H
#define SYSTEM_CONFIG_H

// Debug flags
#define DEBUG_WIFI
#define DEBUG_MQTT
#define DEBUG_SENSORS

// Watchdog timer timeout (in milliseconds)
#define WDT_TIME_MS 30000

#define MQTT_DISCONNECT_TIMEOUT_MS 300000

#define EEPROM_SIZE 512
#define EEPROM_SEND_INTERVAL_ADDR 0

// MQTT configuration
extern const char* mqttServer;
extern const int mqttPort;
extern const char* mqttUser;
extern const char* mqttPassword;
extern const char* deviceESN;

#define RELAY_1  14  
#define RELAY_2  27
#define RELAY_3  33
#define RELAY_4  32


#define RELAY_ON  0
#define RELAY_OFF 1

extern bool relay_state_1;
extern bool relay_state_2;
extern bool relay_state_3;
extern bool relay_state_4;

// Pin Definition
#define MASTER_RO 16
#define MASTER_DI 17
#define MASTER_EN 5

#define LED_INDICATOR 25

#define LED_ON   HIGH
#define LED_OFF  LOW

#define PH_SENSOR_ADDR   0x02
#define WATER_LEVEL_ADDR 0x01
#define DO_SENSOR_ADDR   0x03




// Nextion Assets

#define TEMPERATURE_LABEL 4
#define HUMIDITY_LABEL    5
#define WIFI_OK           1
#define WIFI_NOK          7
#define SERVER_OK         0
#define SERVER_NOK        6

#endif // SYSTEM_CONFIG_H

