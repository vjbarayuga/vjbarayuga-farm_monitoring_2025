#include "SystemConfig.h"

// Wi-Fi credentials
const char* wifiSSID = "PLDTinnov";
const char* wifiPass = "Password12345!";

// MQTT configuration variables
const char* mqttServer     = "3.27.210.100";
const int mqttPort         = 1883;
const char* mqttUser       = "mqtt";
const char* mqttPassword   = "ICPHmqtt!";
const char* deviceESN      = "ENV001";  // Not Used for now

// MQTT broker
const char* topicInit       = "ENV_SENSORS/init";
const char* topicConfig     = "ENV_SENSORS/config";
const char* topicSensorData = "ENV_SENSORS/sensor_data";


// Nextion HMI Display instance
EasyNex display(Serial);

