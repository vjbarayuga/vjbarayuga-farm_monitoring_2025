#include "SensorManager.h"
#include <ModbusRTU.h>
#include "SystemConfig.h"
#include <OneWire.h>
#include <DallasTemperature.h>
#include "DFRobot_SHT20.h"
#include "TDSSensor.h"

ModbusRTU modbus;

// Define the task handle
TaskHandle_t xTaskHandle_SensorManager = NULL;
SemaphoreHandle_t xSemaphore_Sensor = NULL;
bool sensorDataReady = false;

// Define the global sensor data
SensorData_t sensorData = { 0 };

DFRobot_SHT20 sht20(&Wire, SHT20_I2C_ADDR);


// Timer interval for reading sensors (in milliseconds)
const uint32_t SENSOR_READ_INTERVAL_MS = 2000;

float prevTDSValue = 0;
bool tdsValid = false;


void modbusTask(void* pvParameters);
void SensorManagerTask(void* pvParameters);
int getMedianNum(int bArray[], int iFilterLen);

void startSensorManagerTask() {

  xSemaphore_Sensor = xSemaphoreCreateMutex();
  if (xSemaphore_Sensor == NULL) {
    Serial.println("Failed to create mutex for sensor");
    return;
  }

  xTaskCreatePinnedToCore(
    SensorManagerTask,           // Task function
    "Sensor Manager",            // Task name
    4096,                        // Stack size
    NULL,                        // Task parameters
    1,                           // Task priority
    &xTaskHandle_SensorManager,  // Task handle
    1                            // Core ID
  );

  // Create a task to handle Modbus communication
  xTaskCreatePinnedToCore(
    modbusTask,    // Function to run
    "ModbusTask",  // Task name
    4096,          // Stack size (in bytes)
    NULL,          // Task parameter
    1,             // Priority
    NULL,          // Task handle
    1              // Core ID (1 for ESP32 dual-core)
  );
}

// Modbus task function
void modbusTask(void* pvParameters) {
  for (;;) {

    // Handle Modbus tasks
    modbus.task();

    // Small delay to prevent CPU hogging
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void SensorManagerTask(void* pvParameters) {
  Serial.print("Sensor Manager running on core ");
  Serial.println(xPortGetCoreID());

  // Initialize sensor peripherals here
  Serial.println("Initializing sensors...");
  // For example, initialize DHT sensor, ADC, etc.

  // Initialize Modbus Port as Master
  Serial1.begin(9600, SERIAL_8N1, MASTER_RO, MASTER_DI);
  modbus.begin(&Serial1, MASTER_EN);
  modbus.setBaudrate(9600);
  modbus.master();

  Serial.println("Modbus Master Initialized");

  // Change PH ID to 2
  //modbus.writeHreg(1, 0x0050, 0x02);
  vTaskDelay(1000);

  // Initialize DS18B20 Sensor
  OneWire oneWire(ONEWIRE_BUS);
  DallasTemperature ds18b20(&oneWire);
  ds18b20.begin();

  //Initialize TDS Sensor
  TDSSensor tds(TDS_PIN);
  tds.begin();

  // Init SHT20 Sensor
  sht20.initSHT20();

  



  uint32_t lastReadTime = -1 * SENSOR_READ_INTERVAL_MS;  // to read ASAP


  // Main task loop
  for (;;) {
    if (millis() - lastReadTime >= SENSOR_READ_INTERVAL_MS) {
      

      // Time to read sensors
      Serial.println("Reading sensors...");

      if (xSemaphoreTake(xSemaphore_Sensor, portMAX_DELAY) == pdTRUE) {

        // read ph level
        uint16_t modbus_resp[16];
        bool res = modbus.readHreg(1, 0x0000, modbus_resp, 1, nullptr);

        vTaskDelay(1000);  // Example delay

        if (res == true) {
          sensorData.ph_level = modbus_resp[0] / 100.0;


#ifdef DEBUG_SENSORS
          Serial.println("   PH Level 1: " + String(sensorData.ph_level));
#endif
        } else {
          Serial.println("Error reading PH sensor");
        }

        res = modbus.readHreg(2, 0x0000, modbus_resp, 1, nullptr);

        vTaskDelay(1000);  // Example delay

        if (res == true) {
          sensorData.ph_level = modbus_resp[0] / 100.0;


#ifdef DEBUG_SENSORS
          Serial.println("   PH Level 2: " + String(sensorData.ph_level));
#endif
        } else {
          Serial.println("Error reading PH sensor");
        }

        ///////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////


        // read water temperature
        ds18b20.requestTemperatures();
        sensorData.water_temperature = ds18b20.getTempCByIndex(0);

#ifdef DEBUG_SENSORS
        Serial.println("   Water Temperature: " + String(sensorData.water_temperature) + " ºC");
#endif

        // read water level
        modbus.readHreg(1, 0x0002, modbus_resp, 3, nullptr);
        vTaskDelay(1000);  // Example delay

        if (res == true) {
          sensorData.water_level = modbus_resp[2] / 1000.0;


#ifdef DEBUG_SENSORS
          Serial.println("Water Level: " + String(sensorData.water_level) + " mH20");
#endif
        } else {
          Serial.println("Error reading Water Level sensor");
        }

        // read temperature and humidity
        sensorData.temperature = sht20.readTemperature();
        sensorData.humidity = sht20.readHumidity();

#ifdef DEBUG_SENSORS
        Serial.print("Temperature: ");
        Serial.println(sensorData.temperature);
        Serial.print("Humidity: ");
        Serial.println(sensorData.humidity);
        
#endif

      
          
        

        // read EC/TDS sensor
        sensorData.ec = tds.read(sensorData.water_temperature);

        tdsValid = abs(sensorData.ec - prevTDSValue) < 1 ? true : false;
        prevTDSValue = sensorData.ec;
#ifdef DEBUG_SENSORS
        Serial.println("   TDS: " + String(sensorData.ec) + " ppm");
        Serial.println("TDS Valid: " + String(tdsValid));
#endif

        xSemaphoreGive(xSemaphore_Sensor);
        sensorDataReady = tdsValid ? true : false;
      }


      // Reset timer
      lastReadTime = millis();
    }
  }
  // Task delay to yield execution
  vTaskDelay(pdMS_TO_TICKS(100));
}
