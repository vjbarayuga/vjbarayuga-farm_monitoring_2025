#ifndef TDS_SENSOR_H
#define TDS_SENSOR_H

#include <Arduino.h>

class TDSSensor {
public:
    TDSSensor(uint8_t pin, float vref = 3.3, size_t sampleCount = 30)
        : sensorPin(pin), VREF(vref), SCOUNT(sampleCount) {
        analogBuffer = new int[SCOUNT];
        analogBufferIndex = 0;
    }

    ~TDSSensor() {
        delete[] analogBuffer;
    }

    void begin() {
        pinMode(sensorPin, INPUT);
    }

    float read(float currentTemperature) {
        // Sample the ADC value
        analogBuffer[analogBufferIndex] = analogRead(sensorPin);
        analogBufferIndex = (analogBufferIndex + 1) % SCOUNT;

        // Perform median filtering
        float averageVoltage = getMedianVoltage();

        // Apply temperature compensation
        float compensationCoefficient = 1.0 + 0.02 * (currentTemperature - 25.0);
        float compensationVoltage = averageVoltage / compensationCoefficient;

        // Convert voltage to TDS value
        tdsValue = (133.42 * compensationVoltage * compensationVoltage * compensationVoltage 
                    - 255.86 * compensationVoltage * compensationVoltage 
                    + 857.39 * compensationVoltage) * 0.5;
        return tdsValue;
    }

private:
    uint8_t sensorPin;
    float VREF;
    size_t SCOUNT;
    int* analogBuffer;
    size_t analogBufferIndex;
    float tdsValue;

    float getMedianVoltage() {
        int* bufferCopy = new int[SCOUNT];
        memcpy(bufferCopy, analogBuffer, SCOUNT * sizeof(int));

        // Sort array to find the median
        for (size_t i = 0; i < SCOUNT - 1; ++i) {
            for (size_t j = i + 1; j < SCOUNT; ++j) {
                if (bufferCopy[i] > bufferCopy[j]) {
                    int temp = bufferCopy[i];
                    bufferCopy[i] = bufferCopy[j];
                    bufferCopy[j] = temp;
                }
            }
        }

        // Calculate median
        float median;
        if (SCOUNT % 2 == 0) {
            median = (bufferCopy[SCOUNT / 2 - 1] + bufferCopy[SCOUNT / 2]) / 2.0;
        } else {
            median = bufferCopy[SCOUNT / 2];
        }

        delete[] bufferCopy;
        return median * VREF / 4096.0;
    }
};

#endif
